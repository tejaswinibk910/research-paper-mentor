'use client';

// Example Progress Page
// Shows how to use the ProgressDashboard component

import { useEffect, useState } from 'react';
import { ProgressDashboard } from '@/components/ProgressDashboard';
import { api } from '@/lib/api';

export default function ProgressPage() {
  const [userId, setUserId] = useState<string>('');
  const [paperId, setPaperId] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get current user and paper from your app state/context
    const loadUserData = async () => {
      try {
        // Get current user
        const user = await api.getCurrentUser();
        setUserId(user.id);

        // Get paper ID from URL or state
        // For demo, using a hardcoded value
        const currentPaperId = 'your-paper-id-here';
        setPaperId(currentPaperId);
      } catch (error) {
        console.error('Failed to load user data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadUserData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your progress...</p>
        </div>
      </div>
    );
  }

  if (!userId || !paperId) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            No Paper Selected
          </h2>
          <p className="text-gray-600 mb-6">
            Please upload a paper and extract concepts first.
          </p>
          <a
            href="/upload"
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Upload Paper
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Learning Progress
          </h1>
          <p className="text-gray-600">
            Track your understanding and review schedule
          </p>
        </div>

        {/* Progress Dashboard */}
        <ProgressDashboard paperId={paperId} userId={userId} />

        {/* Quick Actions */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => window.location.href = '/quiz'}
            className="p-6 bg-white border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:shadow-lg transition-all text-center"
          >
            <div className="text-4xl mb-2">📝</div>
            <h3 className="font-semibold text-lg mb-1">Take a Quiz</h3>
            <p className="text-sm text-gray-600">Test your knowledge</p>
          </button>

          <button
            onClick={() => window.location.href = '/tutor'}
            className="p-6 bg-white border-2 border-gray-200 rounded-lg hover:border-green-500 hover:shadow-lg transition-all text-center"
          >
            <div className="text-4xl mb-2">💬</div>
            <h3 className="font-semibold text-lg mb-1">Ask Tutor</h3>
            <p className="text-sm text-gray-600">Get help with concepts</p>
          </button>

          <button
            onClick={() => window.location.href = '/review'}
            className="p-6 bg-white border-2 border-gray-200 rounded-lg hover:border-purple-500 hover:shadow-lg transition-all text-center"
          >
            <div className="text-4xl mb-2">🔄</div>
            <h3 className="font-semibold text-lg mb-1">Review Concepts</h3>
            <p className="text-sm text-gray-600">Reinforce your learning</p>
          </button>
        </div>
      </div>
    </div>
  );
}