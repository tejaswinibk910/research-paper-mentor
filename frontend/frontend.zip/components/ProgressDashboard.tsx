// Progress Dashboard Component
// Shows concept understanding, retention stats, and concepts due for review

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';

export function ProgressDashboard({ paperId, userId }: { paperId: string; userId: string }) {
  const [progress, setProgress] = useState<any[]>([]);
  const [dueForReview, setDueForReview] = useState<any>(null);
  const [retentionStats, setRetentionStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const loadProgress = async () => {
    setLoading(true);
    try {
      // Load all progress data
      const [conceptProgress, dueConcepts, stats] = await Promise.all([
        api.getUserProgress(userId, paperId),
        api.getConceptsDueForReview(userId, paperId),
        api.getRetentionStats(userId, paperId),
      ]);

      setProgress(conceptProgress);
      setDueForReview(dueConcepts);
      setRetentionStats(stats);
    } catch (error) {
      console.error('Failed to load progress:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProgress();
    
    // Refresh every 30 seconds to see updates
    const interval = setInterval(loadProgress, 30000);
    return () => clearInterval(interval);
  }, [paperId, userId]);

  if (loading) {
    return <div>Loading progress...</div>;
  }

  return (
    <div className="progress-dashboard">
      <div className="dashboard-header">
        <h2>Your Learning Progress</h2>
        <button onClick={loadProgress} className="refresh-button">
          🔄 Refresh
        </button>
      </div>

      {/* Retention Statistics */}
      {retentionStats && (
        <div className="retention-stats">
          <h3>Overall Statistics</h3>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-value">
                {(retentionStats.overall_retention * 100).toFixed(1)}%
              </div>
              <div className="stat-label">Overall Retention</div>
            </div>
            
            <div className="stat-card mastered">
              <div className="stat-value">{retentionStats.concepts_mastered}</div>
              <div className="stat-label">Concepts Mastered</div>
            </div>
            
            <div className="stat-card in-progress">
              <div className="stat-value">{retentionStats.concepts_in_progress}</div>
              <div className="stat-label">In Progress</div>
            </div>
            
            <div className="stat-card struggling">
              <div className="stat-value">{retentionStats.concepts_struggling}</div>
              <div className="stat-label">Need Review</div>
            </div>
          </div>
        </div>
      )}

      {/* Concepts Due for Review */}
      {dueForReview && dueForReview.count > 0 && (
        <div className="due-for-review">
          <h3>📚 Concepts Due for Review ({dueForReview.count})</h3>
          <div className="concept-list">
            {dueForReview.concepts.map((concept: any) => (
              <div key={concept.id} className="concept-card due">
                <h4>{concept.name}</h4>
                <p>{concept.definition}</p>
                <span className="difficulty">{concept.difficulty}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* All Concepts Progress */}
      <div className="concepts-progress">
        <h3>All Concepts</h3>
        {progress.length === 0 ? (
          <p className="no-data">
            Take a quiz to start tracking your progress!
          </p>
        ) : (
          <div className="concept-list">
            {progress.map((understanding: any) => (
              <ConceptProgressCard
                key={understanding.concept_id}
                understanding={understanding}
                paperId={paperId}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ConceptProgressCard({ understanding, paperId }: any) {
  const [concept, setConcept] = useState<any>(null);

  useEffect(() => {
    // Load concept details
    const loadConcept = async () => {
      try {
        const concepts = await api.getPaperConcepts(paperId);
        const foundConcept = concepts.concepts.find(
          (c: any) => c.id === understanding.concept_id
        );
        setConcept(foundConcept);
      } catch (error) {
        console.error('Failed to load concept:', error);
      }
    };
    loadConcept();
  }, [understanding.concept_id, paperId]);

  if (!concept) {
    return <div>Loading...</div>;
  }

  const confidencePercent = (understanding.confidence_level * 100).toFixed(0);
  const isUnderstood = understanding.is_understood;
  const timesQuizzed = understanding.times_quizzed;

  return (
    <div className={`concept-card ${isUnderstood ? 'understood' : ''}`}>
      <div className="concept-header">
        <h4>{concept.name}</h4>
        {isUnderstood && <span className="badge">✓ Mastered</span>}
      </div>

      <p className="concept-definition">{concept.definition}</p>

      {/* Progress Bar */}
      <div className="progress-bar">
        <div
          className="progress-fill"
          style={{ width: `${confidencePercent}%` }}
        />
      </div>
      <div className="progress-label">
        Confidence: {confidencePercent}%
      </div>

      {/* Stats */}
      <div className="concept-stats">
        <span>📝 Quizzed: {timesQuizzed} times</span>
        <span>✓ Correct: {understanding.correct_answers}</span>
        <span>📅 Reviewed: {understanding.times_reviewed} times</span>
      </div>

      {/* Next Review */}
      {understanding.next_review && (
        <div className="next-review">
          Next review: {new Date(understanding.next_review).toLocaleDateString()}
        </div>
      )}
    </div>
  );
}

// CSS
const styles = `
.progress-dashboard {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.dashboard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
}

.refresh-button {
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.retention-stats {
  margin-bottom: 40px;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-top: 20px;
}

.stat-card {
  padding: 20px;
  background-color: #f8f9fa;
  border-radius: 8px;
  text-align: center;
  border: 2px solid #ddd;
}

.stat-card.mastered {
  border-color: #5cb85c;
  background-color: #f0fff0;
}

.stat-card.in-progress {
  border-color: #f0ad4e;
  background-color: #fffdf0;
}

.stat-card.struggling {
  border-color: #d9534f;
  background-color: #fff5f5;
}

.stat-value {
  font-size: 36px;
  font-weight: bold;
  color: #333;
}

.stat-label {
  font-size: 14px;
  color: #666;
  margin-top: 10px;
}

.due-for-review {
  margin-bottom: 40px;
  padding: 20px;
  background-color: #fff3cd;
  border-radius: 8px;
  border: 2px solid #ffc107;
}

.concept-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
  margin-top: 20px;
}

.concept-card {
  padding: 20px;
  background-color: white;
  border: 2px solid #ddd;
  border-radius: 8px;
  transition: all 0.2s;
}

.concept-card:hover {
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.concept-card.understood {
  border-color: #5cb85c;
  background-color: #f0fff0;
}

.concept-card.due {
  border-color: #ffc107;
}

.concept-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.badge {
  padding: 5px 10px;
  background-color: #5cb85c;
  color: white;
  border-radius: 5px;
  font-size: 12px;
}

.difficulty {
  display: inline-block;
  padding: 3px 8px;
  background-color: #007bff;
  color: white;
  border-radius: 3px;
  font-size: 12px;
  text-transform: capitalize;
}

.concept-definition {
  font-size: 14px;
  color: #666;
  margin: 10px 0;
}

.progress-bar {
  width: 100%;
  height: 8px;
  background-color: #e0e0e0;
  border-radius: 4px;
  overflow: hidden;
  margin: 15px 0 5px 0;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #5cb85c, #4caf50);
  transition: width 0.3s ease;
}

.progress-label {
  font-size: 12px;
  color: #666;
  text-align: right;
}

.concept-stats {
  display: flex;
  gap: 15px;
  margin-top: 15px;
  font-size: 13px;
  color: #666;
}

.next-review {
  margin-top: 10px;
  padding: 8px;
  background-color: #f0f8ff;
  border-radius: 5px;
  font-size: 13px;
  text-align: center;
}

.no-data {
  text-align: center;
  padding: 40px;
  color: #999;
  font-style: italic;
}
`;

export default ProgressDashboard;
