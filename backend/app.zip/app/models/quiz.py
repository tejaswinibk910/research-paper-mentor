from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum


class QuestionType(str, Enum):
    """Types of quiz questions"""
    MULTIPLE_CHOICE = "multiple_choice"
    TRUE_FALSE = "true_false"
    SHORT_ANSWER = "short_answer"
    CONCEPT_MATCHING = "concept_matching"


class QuestionDifficulty(str, Enum):
    """Question difficulty levels"""
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


class Question(BaseModel):
    """Quiz question model"""
    id: str
    type: QuestionType
    difficulty: QuestionDifficulty
    question: str
    options: Optional[List[str]] = None  # For multiple choice
    correct_answer: str
    explanation: str
    concept_id: str  # Added: Link to specific concept
    paper_id: str  # Added: Link to paper
    concepts: List[str] = []  # Keep for backward compatibility
    page_reference: Optional[int] = None
    distractor_explanations: Optional[Dict[str, str]] = None  # Added: For multiple choice


class QuizAnswer(BaseModel):
    """Individual quiz answer - ADDED THIS"""
    question_id: str
    user_answer: str
    is_correct: bool = False
    time_taken_seconds: Optional[int] = None


class Quiz(BaseModel):
    """Quiz model"""
    id: str
    paper_id: str
    user_id: Optional[str] = None  # Made optional
    title: str = "Concept Check Quiz"  # Added: Quiz title
    questions: List[Question]
    total_questions: int  # Added: Track total
    target_concepts: List[str] = []  # Added: Concepts being quizzed
    difficulty: QuestionDifficulty = QuestionDifficulty.MEDIUM  # Made optional with default
    difficulty_level: QuestionDifficulty = QuestionDifficulty.MEDIUM  # Alias
    created_at: datetime = Field(default_factory=datetime.utcnow)
    time_limit: Optional[int] = None  # in minutes
    is_adaptive: bool = False  # Added: Is this an adaptive quiz


class QuizGenerationRequest(BaseModel):
    """Request to generate a quiz - RENAMED from QuizRequest"""
    paper_id: str
    user_id: Optional[str] = None
    num_questions: int = 5
    difficulty: Optional[QuestionDifficulty] = None
    focus_concepts: Optional[List[str]] = None  # Added: Focus on specific concepts
    question_types: List[QuestionType] = [
        QuestionType.MULTIPLE_CHOICE,
        QuestionType.TRUE_FALSE
    ]
    time_limit: Optional[int] = 30  # minutes


class AdaptiveQuizRequest(BaseModel):
    """Request to generate adaptive quiz - ADDED THIS"""
    paper_id: str
    user_id: str
    num_questions: int = 5


# Keep QuizRequest for backward compatibility
QuizRequest = QuizGenerationRequest


class QuizResponse(BaseModel):
    """Response with generated quiz"""
    quiz_id: str
    questions: List[Question]
    time_limit: Optional[int] = None


class QuizSubmission(BaseModel):
    """Quiz submission from user"""
    answers: Dict[str, str]  # question_id -> answer
    time_taken: int  # seconds


class QuizResult(BaseModel):
    """Quiz result after grading"""
    quiz_id: str
    user_id: str
    paper_id: str  # Added: Link to paper
    answers: List[QuizAnswer]  # Added: Detailed answers
    score: float  # percentage
    score_percentage: float  # Alias for compatibility
    total_questions: int
    correct_answers: int
    time_taken: int = 0  # Made optional with default
    submitted_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: datetime = Field(default_factory=datetime.utcnow)  # Alias
    question_results: List[Dict[str, Any]] = []
    weak_concepts: List[str] = []
    strong_concepts: List[str] = []  # Added: Track strong concepts too
    concept_scores: Dict[str, float] = {}  # Added: Score per concept
    
    def __init__(self, **data):
        super().__init__(**data)
        # Auto-populate score_percentage if not provided
        if 'score_percentage' not in data and 'score' in data:
            self.score_percentage = self.score
        elif 'score' not in data and 'score_percentage' in data:
            self.score = self.score_percentage