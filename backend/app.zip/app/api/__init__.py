﻿"""
API Package
"""

from app.api import routes

__all__ = ["routes"]