from fastapi import APIRouter, HTTPException, Depends
from typing import Dict, List
import uuid
from datetime import datetime
from app.models.quiz import (
    Quiz, QuizRequest, QuizResponse,
    Question, QuestionType, QuestionDifficulty,
    QuizSubmission, QuizResult
)
from app.services.quiz_generator import QuizGenerator
from app.api.routes.papers import papers_db, concept_graphs_db
from app.core.deps import get_current_user
from app.models.user import User

router = APIRouter()

# In-memory storage
quizzes_db: Dict[str, Quiz] = {}
quiz_results_db: Dict[str, QuizResult] = {}


@router.post("/quiz/generate", response_model=QuizResponse)
async def generate_quiz(
    request: QuizRequest,
    current_user: User = Depends(get_current_user)
):
    """Generate a new quiz for a paper"""
    if request.paper_id not in papers_db:
        raise HTTPException(status_code=404, detail="Paper not found")
    
    paper = papers_db[request.paper_id]
    
    # Get concepts
    concepts = []
    if request.paper_id in concept_graphs_db:
        concept_graph = concept_graphs_db[request.paper_id]
        concepts = [c.name for c in concept_graph.concepts]
    
    # Get paper content
    paper_text = ""
    if paper:
        paper_text = "\n\n".join([
            f"Section: {section.title}\n{section.content}"
            for section in paper.sections
        ])
    
    # Generate questions
    quiz_generator = QuizGenerator()
    try:
        questions = quiz_generator.generate_questions(
            paper_content=paper_text,
            concepts=concepts,
            num_questions=request.num_questions,
            difficulty=request.difficulty,
            question_types=request.question_types
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating quiz: {str(e)}")
    
    # Create quiz
    quiz_id = str(uuid.uuid4())
    quiz = Quiz(
        id=quiz_id,
        paper_id=request.paper_id,
        user_id=str(current_user.id),
        questions=questions,
        difficulty=request.difficulty,
        time_limit=request.time_limit
    )
    
    quizzes_db[quiz_id] = quiz
    
    return QuizResponse(
        quiz_id=quiz_id,
        questions=questions,
        time_limit=request.time_limit
    )


@router.get("/quiz/{quiz_id}", response_model=Quiz)
async def get_quiz(
    quiz_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get quiz details"""
    if quiz_id not in quizzes_db:
        raise HTTPException(status_code=404, detail="Quiz not found")
    
    quiz = quizzes_db[quiz_id]
    
    # Check if user owns this quiz
    if quiz.user_id != str(current_user.id):
        raise HTTPException(status_code=403, detail="Access denied")
    
    return quiz


@router.post("/quiz/{quiz_id}/submit", response_model=QuizResult)
async def submit_quiz(
    quiz_id: str,
    submission: QuizSubmission,
    current_user: User = Depends(get_current_user)
):
    """Submit quiz answers and get results"""
    if quiz_id not in quizzes_db:
        raise HTTPException(status_code=404, detail="Quiz not found")
    
    quiz = quizzes_db[quiz_id]
    
    # Check if user owns this quiz
    if quiz.user_id != str(current_user.id):
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Grade quiz
    quiz_generator = QuizGenerator()
    total_questions = len(quiz.questions)
    correct_answers = 0
    question_results = []
    
    for question in quiz.questions:
        user_answer = submission.answers.get(question.id, "")
        is_correct = quiz_generator.check_answer(
            question=question,
            user_answer=user_answer
        )
        
        if is_correct:
            correct_answers += 1
        
        question_results.append({
            "question_id": question.id,
            "question": question.question,
            "user_answer": user_answer,
            "correct_answer": question.correct_answer,
            "is_correct": is_correct,
            "explanation": question.explanation
        })
    
    # Calculate score
    score = (correct_answers / total_questions) * 100 if total_questions > 0 else 0
    
    # Identify weak concepts
    weak_concepts = []
    for result in question_results:
        if not result["is_correct"]:
            question = next(q for q in quiz.questions if q.id == result["question_id"])
            weak_concepts.extend(question.concepts)
    
    weak_concepts = list(set(weak_concepts))[:5]  # Top 5 unique weak concepts
    
    # Create result
    result = QuizResult(
        quiz_id=quiz_id,
        user_id=str(current_user.id),
        score=score,
        total_questions=total_questions,
        correct_answers=correct_answers,
        time_taken=submission.time_taken,
        question_results=question_results,
        weak_concepts=weak_concepts
    )
    
    result_id = str(uuid.uuid4())
    quiz_results_db[result_id] = result
    
    return result


@router.get("/quiz/paper/{paper_id}", response_model=List[Quiz])
async def get_paper_quizzes(
    paper_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get all quizzes for a paper"""
    if paper_id not in papers_db:
        raise HTTPException(status_code=404, detail="Paper not found")
    
    quizzes = [
        quiz for quiz in quizzes_db.values()
        if quiz.paper_id == paper_id and quiz.user_id == str(current_user.id)
    ]
    
    return quizzes


@router.get("/quiz/{quiz_id}/results", response_model=List[QuizResult])
async def get_quiz_results(
    quiz_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get all results for a quiz"""
    if quiz_id not in quizzes_db:
        raise HTTPException(status_code=404, detail="Quiz not found")
    
    quiz = quizzes_db[quiz_id]
    
    # Check if user owns this quiz
    if quiz.user_id != str(current_user.id):
        raise HTTPException(status_code=403, detail="Access denied")
    
    results = [
        result for result in quiz_results_db.values()
        if result.quiz_id == quiz_id and result.user_id == str(current_user.id)
    ]
    
    return results


@router.delete("/quiz/{quiz_id}")
async def delete_quiz(
    quiz_id: str,
    current_user: User = Depends(get_current_user)
):
    """Delete a quiz"""
    if quiz_id not in quizzes_db:
        raise HTTPException(status_code=404, detail="Quiz not found")
    
    quiz = quizzes_db[quiz_id]
    
    # Check if user owns this quiz
    if quiz.user_id != str(current_user.id):
        raise HTTPException(status_code=403, detail="Access denied")
    
    del quizzes_db[quiz_id]
    
    # Delete associated results
    results_to_delete = [
        result_id for result_id, result in quiz_results_db.items()
        if result.quiz_id == quiz_id
    ]
    for result_id in results_to_delete:
        del quiz_results_db[result_id]
    
    return {"message": "Quiz deleted successfully"}


@router.post("/quiz/{quiz_id}/retry", response_model=QuizResponse)
async def retry_quiz(
    quiz_id: str,
    current_user: User = Depends(get_current_user)
):
    """Create a new attempt for the same quiz"""
    if quiz_id not in quizzes_db:
        raise HTTPException(status_code=404, detail="Quiz not found")
    
    original_quiz = quizzes_db[quiz_id]
    
    # Check if user owns this quiz
    if original_quiz.user_id != str(current_user.id):
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Create new quiz with same parameters but shuffled questions
    new_quiz_id = str(uuid.uuid4())
    new_quiz = Quiz(
        id=new_quiz_id,
        paper_id=original_quiz.paper_id,
        user_id=str(current_user.id),
        questions=original_quiz.questions.copy(),
        difficulty=original_quiz.difficulty,
        time_limit=original_quiz.time_limit
    )
    
    # Shuffle questions
    import random
    random.shuffle(new_quiz.questions)
    
    quizzes_db[new_quiz_id] = new_quiz
    
    return QuizResponse(
        quiz_id=new_quiz_id,
        questions=new_quiz.questions,
        time_limit=new_quiz.time_limit
    )