from fastapi import APIRouter, HTTPException, Depends
from typing import Dict, List
from datetime import datetime, timedelta
import uuid
from app.models.progress import (
    UserProgress, ConceptMastery, StudySession,
    ProgressSummary, LearningInsight, LearningInsightType,
    ProgressUpdate
)
from app.api.routes.papers import papers_db, concept_graphs_db
from app.api.routes.quiz import quiz_results_db
from app.api.routes.chat import chat_sessions_db
from app.core.deps import get_current_user
from app.models.user import User

router = APIRouter()

# In-memory storage
user_progress_db: Dict[str, UserProgress] = {}
study_sessions_db: Dict[str, List[StudySession]] = {}


def get_or_create_progress(user_id: str, paper_id: str) -> UserProgress:
    """Get or create user progress for a paper"""
    key = f"{user_id}_{paper_id}"
    if key not in user_progress_db:
        user_progress_db[key] = UserProgress(
            user_id=user_id,
            paper_id=paper_id
        )
    return user_progress_db[key]


@router.get("/progress/paper/{paper_id}", response_model=UserProgress)
async def get_paper_progress(
    paper_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get user progress for a specific paper"""
    if paper_id not in papers_db:
        raise HTTPException(status_code=404, detail="Paper not found")
    
    progress = get_or_create_progress(str(current_user.id), paper_id)
    
    # Update progress based on activities
    _update_progress(progress, str(current_user.id), paper_id)
    
    return progress


@router.post("/progress/session/start")
async def start_study_session(
    paper_id: str,
    current_user: User = Depends(get_current_user)
):
    """Start a new study session"""
    if paper_id not in papers_db:
        raise HTTPException(status_code=404, detail="Paper not found")
    
    session_id = str(uuid.uuid4())
    session = StudySession(
        id=session_id,
        paper_id=paper_id,
        user_id=str(current_user.id),
        start_time=datetime.utcnow()
    )
    
    user_id = str(current_user.id)
    if user_id not in study_sessions_db:
        study_sessions_db[user_id] = []
    
    study_sessions_db[user_id].append(session)
    
    return {"session_id": session_id, "message": "Study session started"}


@router.post("/progress/session/end")
async def end_study_session(
    paper_id: str,
    concepts_learned: List[str] = [],
    current_user: User = Depends(get_current_user)
):
    """End current study session"""
    if paper_id not in papers_db:
        raise HTTPException(status_code=404, detail="Paper not found")
    
    user_id = str(current_user.id)
    
    if user_id not in study_sessions_db or not study_sessions_db[user_id]:
        raise HTTPException(status_code=404, detail="No active study session")
    
    # Find the last session for this paper
    sessions = study_sessions_db[user_id]
    current_session = None
    for session in reversed(sessions):
        if session.paper_id == paper_id and session.end_time is None:
            current_session = session
            break
    
    if not current_session:
        raise HTTPException(status_code=404, detail="No active study session for this paper")
    
    current_session.end_time = datetime.utcnow()
    current_session.concepts_learned = concepts_learned
    current_session.duration = int((current_session.end_time - current_session.start_time).total_seconds())
    
    # Update user progress
    progress = get_or_create_progress(user_id, paper_id)
    progress.total_study_time += current_session.duration
    progress.last_studied = current_session.end_time
    
    return {
        "duration": current_session.duration,
        "concepts_learned": len(concepts_learned),
        "message": "Study session ended"
    }


@router.get("/progress/summary", response_model=ProgressSummary)
async def get_progress_summary(current_user: User = Depends(get_current_user)):
    """Get overall progress summary for user"""
    user_id = str(current_user.id)
    
    # Get all user's papers
    user_papers = list(papers_db.values())
    
    total_papers = len(user_papers)
    total_study_time = 0
    papers_mastered = 0
    total_concepts = 0
    mastered_concepts = 0
    
    for paper in user_papers:
        progress = get_or_create_progress(user_id, paper.id)
        _update_progress(progress, user_id, paper.id)
        
        total_study_time += progress.total_study_time
        
        if progress.completion_percentage >= 80:
            papers_mastered += 1
        
        for concept in progress.concepts_mastery:
            total_concepts += 1
            if concept.mastery_level >= 0.8:
                mastered_concepts += 1
    
    # Calculate recent activity (last 7 days)
    recent_sessions = []
    if user_id in study_sessions_db:
        week_ago = datetime.utcnow() - timedelta(days=7)
        recent_sessions = [
            s for s in study_sessions_db[user_id]
            if s.start_time >= week_ago
        ]
    
    # Generate insights
    insights = _generate_insights(user_id, user_papers)
    
    return ProgressSummary(
        user_id=user_id,
        total_papers_studied=total_papers,
        total_study_time=total_study_time,
        papers_mastered=papers_mastered,
        concepts_learned=mastered_concepts,
        total_concepts=total_concepts,
        average_quiz_score=_calculate_average_quiz_score(user_id),
        study_streak=_calculate_study_streak(user_id),
        recent_activity=recent_sessions,
        insights=insights
    )


@router.get("/progress/concepts/{paper_id}", response_model=List[ConceptMastery])
async def get_concept_mastery(
    paper_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get concept mastery levels for a paper"""
    if paper_id not in papers_db:
        raise HTTPException(status_code=404, detail="Paper not found")
    
    progress = get_or_create_progress(str(current_user.id), paper_id)
    _update_progress(progress, str(current_user.id), paper_id)
    
    return progress.concepts_mastery


@router.post("/progress/concept/update")
async def update_concept_mastery(
    update: ProgressUpdate,
    current_user: User = Depends(get_current_user)
):
    """Update mastery level for a concept"""
    if update.paper_id not in papers_db:
        raise HTTPException(status_code=404, detail="Paper not found")
    
    progress = get_or_create_progress(str(current_user.id), update.paper_id)
    
    # Find or create concept mastery
    concept_mastery = None
    if update.concept_id:
        for cm in progress.concepts_mastery:
            if cm.concept_id == update.concept_id:
                concept_mastery = cm
                break
    
    if not concept_mastery and update.concept_id:
        # Get concept name from graph
        concept_name = update.concept_id
        if update.paper_id in concept_graphs_db:
            graph = concept_graphs_db[update.paper_id]
            for c in graph.concepts:
                if c.id == update.concept_id:
                    concept_name = c.name
                    break
        
        concept_mastery = ConceptMastery(
            concept_id=update.concept_id,
            concept_name=concept_name,
            paper_id=update.paper_id
        )
        progress.concepts_mastery.append(concept_mastery)
    
    if concept_mastery:
        # Update mastery
        if update.understood:
            concept_mastery.times_reviewed += 1
            concept_mastery.mastery_level = min(1.0, concept_mastery.mastery_level + 0.1)
        else:
            concept_mastery.times_reviewed += 1
            concept_mastery.mastery_level = max(0.0, concept_mastery.mastery_level - 0.05)
        
        concept_mastery.last_reviewed = datetime.utcnow()
        
        return {"concept": concept_mastery.concept_name, "mastery_level": concept_mastery.mastery_level}
    
    return {"message": "Progress updated"}


def _update_progress(progress: UserProgress, user_id: str, paper_id: str):
    """Update progress based on recent activities"""
    # Count quiz attempts and scores
    quiz_results = [
        r for r in quiz_results_db.values()
        if r.user_id == user_id
    ]
    
    progress.quiz_attempts = len(quiz_results)
    if quiz_results:
        progress.average_quiz_score = sum(r.score for r in quiz_results) / len(quiz_results)
    
    # Count chat sessions
    chat_sessions = [
        s for s in chat_sessions_db.values()
        if s.user_id == user_id and s.paper_id == paper_id
    ]
    
    progress.questions_asked = sum(s.questions_asked for s in chat_sessions)
    
    # Update concept mastery from concepts graph
    if paper_id in concept_graphs_db:
        concept_graph = concept_graphs_db[paper_id]
        
        for concept in concept_graph.concepts:
            # Check if concept already tracked
            existing = next(
                (cm for cm in progress.concepts_mastery if cm.concept_id == concept.id),
                None
            )
            
            if not existing:
                progress.concepts_mastery.append(
                    ConceptMastery(
                        concept_id=concept.id,
                        concept_name=concept.name,
                        paper_id=paper_id,
                        mastery_level=0.0
                    )
                )
    
    # Calculate completion percentage
    if progress.concepts_mastery:
        avg_mastery = sum(c.mastery_level for c in progress.concepts_mastery) / len(progress.concepts_mastery)
        progress.completion_percentage = int(avg_mastery * 100)


def _calculate_average_quiz_score(user_id: str) -> float:
    """Calculate average quiz score across all papers"""
    user_results = [r for r in quiz_results_db.values() if r.user_id == user_id]
    if not user_results:
        return 0.0
    return sum(r.score for r in user_results) / len(user_results)


def _calculate_study_streak(user_id: str) -> int:
    """Calculate current study streak in days"""
    if user_id not in study_sessions_db:
        return 0
    
    sessions = sorted(study_sessions_db[user_id], key=lambda s: s.start_time, reverse=True)
    if not sessions:
        return 0
    
    streak = 0
    current_date = datetime.utcnow().date()
    
    for session in sessions:
        session_date = session.start_time.date()
        
        if session_date == current_date:
            if streak == 0:
                streak = 1
        elif session_date == current_date - timedelta(days=streak + 1):
            streak += 1
        else:
            break
    
    return streak


def _generate_insights(user_id: str, papers: list) -> List[LearningInsight]:
    """Generate learning insights"""
    insights = []
    
    # Check study consistency
    if user_id in study_sessions_db:
        sessions = study_sessions_db[user_id]
        if len(sessions) >= 3:
            insights.append(LearningInsight(
                type=LearningInsightType.ACHIEVEMENT,
                message=f"Great job! You've completed {len(sessions)} study sessions.",
                action="Keep up the consistent study habits!"
            ))
    
    # Check quiz performance
    user_results = [r for r in quiz_results_db.values() if r.user_id == user_id]
    if user_results:
        avg_score = sum(r.score for r in user_results) / len(user_results)
        if avg_score >= 80:
            insights.append(LearningInsight(
                type=LearningInsightType.ACHIEVEMENT,
                message=f"Excellent quiz performance! Average score: {avg_score:.1f}%",
                action="You're mastering the material!"
            ))
        elif avg_score < 60:
            insights.append(LearningInsight(
                type=LearningInsightType.SUGGESTION,
                message=f"Quiz scores could improve. Current average: {avg_score:.1f}%",
                action="Try reviewing weak concepts and asking more questions in chat."
            ))
    
    # Check for papers without recent activity
    week_ago = datetime.utcnow() - timedelta(days=7)
    for paper in papers[:3]:  # Check first 3 papers
        progress = get_or_create_progress(user_id, paper.id)
        if progress.last_studied and progress.last_studied < week_ago:
            insights.append(LearningInsight(
                type=LearningInsightType.REMINDER,
                message=f"Haven't reviewed '{paper.filename}' in a while.",
                action="Consider a quick review session to maintain retention."
            ))
    
    return insights[:5]  # Return top 5 insights