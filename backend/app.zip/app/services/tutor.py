from typing import List, Dict, Optional
from app.core.llm import LLMService
from app.core.vector_store import vector_store
from app.models.chat import (
    ChatSession, Message, MessageRole, TutoringMode,
    ChatResponse, HintResponse
)
from app.models.concept import Concept


class SocraticTutor:
    """
    Socratic tutoring system that guides users to understanding
    through questions rather than direct answers
    """
    
    def __init__(self):
        self.llm = LLMService()
    
    def respond_to_query(
        self,
        session: ChatSession,
        user_message: str,
        concepts: List[Concept],
        page_number: Optional[int] = None
    ) -> ChatResponse:
        """
        Respond to a user query in Socratic mode
        
        Args:
            session: Current chat session
            user_message: User's question
            concepts: Available concepts from paper
            page_number: Optional page reference
            
        Returns:
            ChatResponse with tutor's reply
        """
        print(f"Processing query in {session.tutoring_mode.value} mode...")
        
        # Find relevant context
        relevant_chunks = self._get_relevant_context(
            paper_id=session.paper_id,
            query=user_message,
            page_number=page_number
        )
        
        # Identify related concepts
        related_concepts = self._identify_related_concepts(
            user_message=user_message,
            concepts=concepts
        )
        
        # Generate response based on tutoring mode
        if session.tutoring_mode == TutoringMode.SOCRATIC:
            response_text = self._generate_socratic_response(
                session=session,
                user_message=user_message,
                context=relevant_chunks,
                related_concepts=related_concepts
            )
        elif session.tutoring_mode == TutoringMode.HINT_BASED:
            response_text = self._generate_hint_based_response(
                session=session,
                user_message=user_message,
                context=relevant_chunks,
                related_concepts=related_concepts
            )
        elif session.tutoring_mode == TutoringMode.ANALOGIES:
            response_text = self._generate_analogy_response(
                session=session,
                user_message=user_message,
                related_concepts=related_concepts
            )
        else:  # DIRECT mode
            response_text = self._generate_direct_response(
                session=session,
                user_message=user_message,
                context=relevant_chunks
            )
        
        # Check if response is a question
        is_question = "?" in response_text
        
        # FIXED: Return ChatResponse with string message, not Message object
        response = ChatResponse(
            session_id=session.id,
            message=response_text,  # String, not Message object
            relevant_concepts=[c.id for c in related_concepts],
            is_question=is_question
        )
        
        return response
    
    def _generate_socratic_response(
        self,
        session: ChatSession,
        user_message: str,
        context: List[Dict],
        related_concepts: List[Concept]
    ) -> str:
        """Generate Socratic-style response that guides with questions"""
        
        # Build conversation history
        history = self._build_conversation_history(session)
        
        # Context from paper
        paper_context = "\n\n".join([c["text"] for c in context]) if context else ""
        
        # Concept information
        concept_info = ""
        if related_concepts:
            concept_info = "\n".join([
                f"- {c.name}: {c.definition}"
                for c in related_concepts[:3]
            ])
        
        system_prompt = f"""You are a Socratic tutor helping a student understand a research paper.

TUTORING PRINCIPLES:
1. NEVER give direct answers immediately
2. Guide the student to discover answers through questions
3. Ask one question at a time
4. Build on previous exchanges
5. Only provide direct explanations if the student is truly stuck (after 2-3 question rounds)
6. Reference the paper when relevant

STUDENT BACKGROUND: {session.user_background}

RELEVANT CONCEPTS:
{concept_info}

PAPER CONTEXT:
{paper_context[:2000]}

Remember: Your goal is to help the student THINK, not to give them answers."""

        messages = [
            {"role": "system", "content": system_prompt}
        ] + history + [
            {"role": "user", "content": user_message}
        ]
        
        try:
            response = self.llm.generate(
                messages=messages,
                temperature=0.7,
                max_tokens=400
            )
            return response.strip()
        except Exception as e:
            print(f"Error in LLM generation: {e}")
            return "I'm here to help you understand this paper. What specific aspect would you like to explore?"
    
    def _generate_hint_based_response(
        self,
        session: ChatSession,
        user_message: str,
        context: List[Dict],
        related_concepts: List[Concept]
    ) -> str:
        """Generate progressive hints"""
        
        # Determine hint level based on conversation
        hint_level = self._determine_hint_level(session, user_message)
        
        paper_context = "\n\n".join([c["text"] for c in context]) if context else ""
        
        prompt = f"""The student is asking: "{user_message}"

Provide a hint (level {hint_level} of 3) to guide them:
- Level 1: Very subtle hint, just point them in the right direction
- Level 2: More specific hint, narrow down the possibilities
- Level 3: Clear guidance, almost give the answer but let them make final connection

PAPER CONTEXT:
{paper_context[:1500]}

Hint (level {hint_level}):"""

        history = self._build_conversation_history(session)
        messages = history + [{"role": "user", "content": prompt}]
        
        try:
            response = self.llm.generate(
                messages=messages,
                temperature=0.6,
                max_tokens=300
            )
            return f"💡 Hint {hint_level}/3: {response.strip()}"
        except Exception as e:
            print(f"Error generating hint: {e}")
            return "💡 Try breaking down the question into smaller parts."
    
    def _generate_analogy_response(
        self,
        session: ChatSession,
        user_message: str,
        related_concepts: List[Concept]
    ) -> str:
        """Generate response using analogies"""
        
        concept_info = ""
        if related_concepts:
            c = related_concepts[0]
            concept_info = f"Concept: {c.name}\nDefinition: {c.definition}\nExplanation: {c.explanation}"
        
        prompt = f"""The student asks: "{user_message}"

Explain this using a clear analogy that someone with {session.user_background} background would understand.

{concept_info}

Provide:
1. A concrete analogy from everyday life
2. How the analogy maps to the concept
3. A simple example

Keep it concise and relatable."""

        history = self._build_conversation_history(session)
        messages = history + [{"role": "user", "content": prompt}]
        
        try:
            response = self.llm.generate(
                messages=messages,
                temperature=0.8,
                max_tokens=500
            )
            return response.strip()
        except Exception as e:
            print(f"Error generating analogy: {e}")
            return "Let me explain this concept in simpler terms..."
    
    def _generate_direct_response(
        self,
        session: ChatSession,
        user_message: str,
        context: List[Dict]
    ) -> str:
        """Generate direct answer (non-Socratic)"""
        
        paper_context = "\n\n".join([c["text"] for c in context]) if context else ""
        
        system_prompt = f"""You are a knowledgeable tutor explaining a research paper to a student.

Provide clear, direct explanations. Reference the paper when relevant.

STUDENT BACKGROUND: {session.user_background}

PAPER CONTEXT:
{paper_context[:2000]}"""

        history = self._build_conversation_history(session)
        messages = [
            {"role": "system", "content": system_prompt}
        ] + history + [
            {"role": "user", "content": user_message}
        ]
        
        try:
            response = self.llm.generate(
                messages=messages,
                temperature=0.7,
                max_tokens=500
            )
            return response.strip()
        except Exception as e:
            print(f"Error generating direct response: {e}")
            return "Based on the paper, let me explain..."
    
    def generate_progressive_hints(
        self,
        paper_id: str,
        question: str,
        current_level: int,
        max_level: int = 3
    ) -> HintResponse:
        """Generate a progressive hint"""
        
        # Get context
        context = self._get_relevant_context(paper_id, question)
        paper_context = "\n\n".join([c["text"] for c in context]) if context else ""
        
        if current_level >= max_level:
            # Final hint - give the answer
            prompt = f"""Question: {question}

PAPER CONTEXT:
{paper_context[:1500]}

Provide the complete answer with explanation, citing the paper."""
            
            is_final = True
        else:
            # Progressive hint
            prompt = f"""Question: {question}

PAPER CONTEXT:
{paper_context[:1500]}

Provide hint level {current_level + 1} of {max_level}:
- Level 1: Point in general direction
- Level 2: Narrow down possibilities  
- Level 3: Give clear guidance

Hint:"""
            is_final = False
        
        try:
            response = self.llm.generate(
                messages=[{"role": "user", "content": prompt}],
                temperature=0.6,
                max_tokens=300
            )
            hint_text = response.strip()
        except Exception as e:
            print(f"Error generating progressive hint: {e}")
            hint_text = "Consider reviewing the relevant sections of the paper."
        
        return HintResponse(
            hint=hint_text,
            difficulty="medium"
        )
    
    def _get_relevant_context(
        self,
        paper_id: str,
        query: str,
        page_number: Optional[int] = None,
        n_results: int = 3
    ) -> List[Dict]:
        """Retrieve relevant context from paper"""
        
        try:
            filter_metadata = None
            if page_number:
                filter_metadata = {"page_start": str(page_number)}
            
            results = vector_store.search(
                paper_id=paper_id,
                query=query,
                n_results=n_results,
                filter_metadata=filter_metadata
            )
            
            return results
        except Exception as e:
            print(f"Error retrieving context: {e}")
            return []
    
    def _identify_related_concepts(
        self,
        user_message: str,
        concepts: List[Concept]
    ) -> List[Concept]:
        """Identify concepts related to user's question"""
        
        user_message_lower = user_message.lower()
        
        related = []
        for concept in concepts:
            # Simple keyword matching
            if (concept.name.lower() in user_message_lower or
                any(word in user_message_lower for word in concept.name.lower().split())):
                related.append(concept)
        
        # Sort by importance
        related.sort(key=lambda c: c.importance_score, reverse=True)
        
        return related[:5]
    
    def _build_conversation_history(
        self,
        session: ChatSession,
        max_messages: int = 10
    ) -> List[Dict[str, str]]:
        """Build conversation history for LLM"""
        
        history = []
        for msg in session.messages[-max_messages:]:
            if msg.role != MessageRole.SYSTEM:
                history.append({
                    "role": msg.role.value,
                    "content": msg.content
                })
        
        return history
    
    def _determine_hint_level(
        self,
        session: ChatSession,
        user_message: str
    ) -> int:
        """Determine what hint level to provide"""
        
        # Check if user is asking for help or seems stuck
        stuck_indicators = ["help", "stuck", "don't understand", "confused", "hint"]
        
        if any(indicator in user_message.lower() for indicator in stuck_indicators):
            # Count how many times they've asked
            recent_messages = session.messages[-5:]
            stuck_count = sum(
                1 for msg in recent_messages
                if msg.role == MessageRole.USER and 
                any(indicator in msg.content.lower() for indicator in stuck_indicators)
            )
            return min(stuck_count, 3)
        
        return 1
    
    def _extract_page_references(self, chunks: List[Dict]) -> List[int]:
        """Extract page numbers from chunks"""
        pages = set()
        for chunk in chunks:
            metadata = chunk.get("metadata", {})
            if "page_start" in metadata:
                try:
                    pages.add(int(metadata["page_start"]))
                except:
                    pass
        
        return sorted(list(pages))